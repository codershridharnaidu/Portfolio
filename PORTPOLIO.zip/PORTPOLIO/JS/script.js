// Validation for contact form

document.addEventListener()